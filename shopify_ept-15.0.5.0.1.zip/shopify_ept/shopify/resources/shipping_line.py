from ..base import ShopifyResource


class ShippingLine(ShopifyResource):
    pass
