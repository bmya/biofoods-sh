from ..base import ShopifyResource


class Address(ShopifyResource):
    pass
