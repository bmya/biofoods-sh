from ..base import ShopifyResource


class StorefrontAccessToken(ShopifyResource):
    pass
