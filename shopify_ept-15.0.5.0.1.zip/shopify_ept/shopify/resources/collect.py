from ..base import ShopifyResource


class Collect(ShopifyResource):
    pass
