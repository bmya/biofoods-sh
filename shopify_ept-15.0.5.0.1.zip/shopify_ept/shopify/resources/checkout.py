from ..base import ShopifyResource


class Checkout(ShopifyResource):
    pass
