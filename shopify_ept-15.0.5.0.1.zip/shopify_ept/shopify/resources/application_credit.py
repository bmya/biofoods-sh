from ..base import ShopifyResource


class ApplicationCredit(ShopifyResource):
    pass
